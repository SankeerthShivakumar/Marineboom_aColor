
%parameters defination

L(1) = Link([  0      1        0     pi/2    0]);
L(2) = Link([  0      0        3.1     0       0]);
L(3) = Link([  0      0        2.7     0       0]);


two_link = SerialLink(L,'name','Schematic representation of boom')

% three_link.fkine([0 0 0 0])
% 
% %three_link.tool=transl([0.03,0,0.135])
% 
 two_link.plot([0 -0.5 -1.5])
%% directing the manipulator to the first point[-1,0.3,1.6]
% p1=transl([0.753,1,3])
% 
% hold on
% trplot(p1,'frame','P','color','b')
% 
% Qp1=three_link.ikunc(p1)
%  %three_link.fkine(Qp1)
  two_link.teach(Qp1)
%  three_link.plot(Qp1)

