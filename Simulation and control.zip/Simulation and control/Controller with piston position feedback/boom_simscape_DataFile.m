% Simscape(TM) Multibody(TM) version: 5.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(53).translation = [0.0 0.0 0.0];
smiData.RigidTransform(53).angle = 0.0;
smiData.RigidTransform(53).axis = [0.0 0.0 0.0];
smiData.RigidTransform(53).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [10.000000000000009 -290.00000000000023 -3101.8870556466268];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Manipulator_part1-1:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [13.906424308456744 -203.11308493013431 1053.4030965769477];  % mm
smiData.RigidTransform(2).angle = 2.0902221512283288;  % rad
smiData.RigidTransform(2).axis = [-0.57595255460223305 -0.58013559595522513 0.57595255460223249];
smiData.RigidTransform(2).ID = 'F[Manipulator_part1-1:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-24.09357569156062 23.531808382689977 729.99999999999955];  % mm
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [1 0 0];
smiData.RigidTransform(3).ID = 'B[Alamarin_piston_rod_analysis-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [696.53890576045683 25.52920325867419 11.235346177411543];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(4).axis = [-0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(4).ID = 'F[Alamarin_piston_rod_analysis-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [99.999999999999972 0 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[pin2-1:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [23.906424308457019 23.53618291978329 12.999999999999877];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(6).axis = [-0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(6).ID = 'F[pin2-1:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [99.999999999999972 0 0];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[pin2-2:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [23.906424308439398 23.536182919783219 717.99999999999943];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(8).ID = 'F[pin2-2:-:Alamarin_piston_rod_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 -23.748510824797677 -2964.8062447819079];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Manipulator_part1-1:-:Link_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [128.30917874460366 -6.2801932387889394 -0.99999999998263434];  % mm
smiData.RigidTransform(10).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(10).axis = [-1 1.2571412258267763e-32 -1.3112292897690424e-16];
smiData.RigidTransform(10).ID = 'F[Manipulator_part1-1:-:Link_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-151.69082125603862 -6.280193236715137 0];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'B[Link_1-1:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [112.00000000000014 -1.9790604710578918e-09 1.546140993013978e-10];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962595 0.57735026918962562 0.57735026918962573];
smiData.RigidTransform(12).ID = 'F[Link_1-1:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-151.69082125603862 -6.280193236715137 0];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'B[Link_1-1:-:linkl_2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [10.000000000000426 25.912563665342127 -186.77419354778161];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(14).ID = 'F[Link_1-1:-:linkl_2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [100 -23.748510824797563 -2964.8062447819079];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Manipulator_part1-1:-:Link_1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-151.69082125669212 -6.2801932388244239 -1.0000000000176215];  % mm
smiData.RigidTransform(16).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(16).axis = [1 -4.031153592686531e-32 -3.1527784642326054e-16];
smiData.RigidTransform(16).ID = 'F[Manipulator_part1-1:-:Link_1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [128.30917874396118 -6.2801932367149149 0];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = 'B[Link_1-2:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [9.9999999999994884 -2.0128254618612118e-09 1.5734258340671659e-10];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(18).axis = [-0.57735026918962618 -0.5773502691896254 0.57735026918962562];
smiData.RigidTransform(18).ID = 'F[Link_1-2:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [128.30917874396118 -6.2801932367149149 0];  % mm
smiData.RigidTransform(19).angle = 0;  % rad
smiData.RigidTransform(19).axis = [0 0 0];
smiData.RigidTransform(19).ID = 'B[Link_1-2:-:linkl_2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-2.8421709430404007e-14 25.912563669155325 53.225806450997041];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962529 -0.57735026918962595 0.57735026918962595];
smiData.RigidTransform(20).ID = 'F[Link_1-2:-:linkl_2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [190 199.25836632796128 -46.742791129677066];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[base____1-1:-:Manipulator_part1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-89.999999999982435 -110.00000000000004 53.431457505076239];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962618 0.57735026918962562 0.57735026918962562];
smiData.RigidTransform(22).ID = 'F[base____1-1:-:Manipulator_part1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 -120.73361429298235 -3076.8870556466272];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[Manipulator_part1-1:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-966.7782739484885 -82.330511018653837 -11.000000000017963];  % mm
smiData.RigidTransform(24).angle = 1.1102230246251565e-16;  % rad
smiData.RigidTransform(24).axis = [-0.71560850098563966 -0.69850159149216406 2.7747453047665747e-17];
smiData.RigidTransform(24).ID = 'F[Manipulator_part1-1:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [0 -70.8854907703968 -2059.8710644886824];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[Manipulator_part1-1:-:pin2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [100.00000000000003 5.6843418860808015e-14 1.8189894035458565e-12];  % mm
smiData.RigidTransform(26).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(26).axis = [-0.57735026918962606 -0.57735026918962584 0.57735026918962551];
smiData.RigidTransform(26).ID = 'F[Manipulator_part1-1:-:pin2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 -65.783794079923297 -2764.8526051625349];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[Manipulator_part1-1:-:pin2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [100.00000000001756 5.6843418860808015e-14 2.2737367544323206e-12];  % mm
smiData.RigidTransform(28).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(28).axis = [-0.57735026918962606 -0.57735026918962584 0.57735026918962551];
smiData.RigidTransform(28).ID = 'F[Manipulator_part1-1:-:pin2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [0 -45.069586370801886 -367.37984354897577];  % mm
smiData.RigidTransform(29).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(29).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(29).ID = 'B[Manipulator_part1-1:-:pin3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [100.00000000000003 5.6843418860808015e-14 1.7053025658242404e-13];  % mm
smiData.RigidTransform(30).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(30).axis = [-0.57735026918962606 -0.57735026918962584 0.57735026918962551];
smiData.RigidTransform(30).ID = 'F[Manipulator_part1-1:-:pin3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [448.30917874396147 -6.28019323671497 0];  % mm
smiData.RigidTransform(31).angle = 0;  % rad
smiData.RigidTransform(31).axis = [0 0 0];
smiData.RigidTransform(31).ID = 'B[Link_1_cylinder_1-1:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [31.699999999999221 0 0];  % mm
smiData.RigidTransform(32).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(32).axis = [-0.57735026918962618 -0.57735026918962562 0.5773502691896254];
smiData.RigidTransform(32).ID = 'F[Link_1_cylinder_1-1:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [448.30917874396101 -6.2801932367149425 0];  % mm
smiData.RigidTransform(33).angle = 0;  % rad
smiData.RigidTransform(33).axis = [0 0 0];
smiData.RigidTransform(33).ID = 'B[Link_1_cylinder_1-2:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [102.00000000000009 2.8421709430404007e-14 0];  % mm
smiData.RigidTransform(34).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(34).axis = [-0.57735026918962562 -0.57735026918962584 0.57735026918962595];
smiData.RigidTransform(34).ID = 'F[Link_1_cylinder_1-2:-:PIN_simu_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [35 15.000000000000002 -11.524753488174611];  % mm
smiData.RigidTransform(35).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(35).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(35).ID = 'B[base____1-1:-:cylinder_base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [-5.3290705182007514e-15 14.999999999999968 -20.000000000000004];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(36).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(36).ID = 'F[base____1-1:-:cylinder_base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [-151.69082125603816 -6.28019323671497 0];  % mm
smiData.RigidTransform(37).angle = 0;  % rad
smiData.RigidTransform(37).axis = [0 0 0];
smiData.RigidTransform(37).ID = 'B[Link_1_cylinder_1-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [25.000000000000767 -35.970796741325721 42.535346177411881];  % mm
smiData.RigidTransform(38).angle = 1.2048267376887362e-16;  % rad
smiData.RigidTransform(38).axis = [0.41577250600252552 -0.9094686488562318 -2.2779180769030042e-17];
smiData.RigidTransform(38).ID = 'F[Link_1_cylinder_1-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [-151.69082125603904 -6.2801932367149425 0];  % mm
smiData.RigidTransform(39).angle = 0;  % rad
smiData.RigidTransform(39).axis = [0 0 0];
smiData.RigidTransform(39).ID = 'B[Link_1_cylinder_1-2:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [25.000000000000291 -35.970796741325714 -27.764653822588336];  % mm
smiData.RigidTransform(40).angle = 1.4709025601273636e-15;  % rad
smiData.RigidTransform(40).axis = [0.8971765655742453 0.44167206181102514 2.9142832354723286e-16];
smiData.RigidTransform(40).ID = 'F[Link_1_cylinder_1-2:-:alamarin_cyl_for_manipulator_for_sim-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [0 25.91256366723249 53.225806451612897];  % mm
smiData.RigidTransform(41).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(41).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(41).ID = 'B[linkl_2-1:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-826.62751012421381 -17.165727180742209 -2.0000000000004547];  % mm
smiData.RigidTransform(42).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(42).axis = [-1 3.302362845373505e-34 -5.6522619549924952e-17];
smiData.RigidTransform(42).ID = 'F[linkl_2-1:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [0 25.91256366723249 53.225806451612897];  % mm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[linkl_2-1:-:Link_1_cylinder_1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [680.69135435252645 -66.267895805073863 4.5474735088646412e-13];  % mm
smiData.RigidTransform(44).angle = 9.7839788123181702e-16;  % rad
smiData.RigidTransform(44).axis = [-0.79379939350218431 -0.60817967976212783 2.3617187428798436e-16];
smiData.RigidTransform(44).ID = 'F[linkl_2-1:-:Link_1_cylinder_1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [0 25.91256366723249 -186.77419354838688];  % mm
smiData.RigidTransform(45).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(45).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(45).ID = 'B[linkl_2-2:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [-826.62751012421381 -17.165727180742437 89.999999999999659];  % mm
smiData.RigidTransform(46).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(46).axis = [1 4.5250061417888209e-32 1.479887696542266e-16];
smiData.RigidTransform(46).ID = 'F[linkl_2-2:-:Manipulator_part2_for_simulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [-151.69082125603816 -6.28019323671497 10.000000000000009];  % mm
smiData.RigidTransform(47).angle = 0;  % rad
smiData.RigidTransform(47).axis = [0 0 0];
smiData.RigidTransform(47).ID = 'B[Link_1_cylinder_1-1:-:linkl_2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [11.700000000000045 175.8818200881293 634.18124547302682];  % mm
smiData.RigidTransform(48).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(48).axis = [-0.5773502691896254 -0.57735026918962595 0.57735026918962595];
smiData.RigidTransform(48).ID = 'F[Link_1_cylinder_1-1:-:linkl_2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [0 0 300.00000000000006];  % mm
smiData.RigidTransform(49).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(49).axis = [1 0 0];
smiData.RigidTransform(49).ID = 'B[cylinder_base-1:-:base_piston_ikh_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [0 378.07021438524305 5.6843418860808015e-14];  % mm
smiData.RigidTransform(50).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(50).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(50).ID = 'F[cylinder_base-1:-:base_piston_ikh_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [99.999999999999972 0 0];  % mm
smiData.RigidTransform(51).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(51).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(51).ID = 'B[pin3-1:-:base_piston_ikh_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [5.6843418860808015e-14 520.1767388908944 50.000000000017565];  % mm
smiData.RigidTransform(52).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(52).axis = [1 -8.5510082223637745e-34 -5.3126456729564405e-17];
smiData.RigidTransform(52).ID = 'F[pin3-1:-:base_piston_ikh_analysis-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [205.44780801527469 -5.7560646189655094 121.21786971173893];  % mm
smiData.RigidTransform(53).angle = 0;  % rad
smiData.RigidTransform(53).axis = [0 0 0];
smiData.RigidTransform(53).ID = 'RootGround[base____1-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

% Initialize the Solid structure array by filling in null values.
smiData.Solid(13).mass = 0.0;
smiData.Solid(13).CoM = [0.0 0.0 0.0];
smiData.Solid(13).MoI = [0.0 0.0 0.0];
smiData.Solid(13).PoI = [0.0 0.0 0.0];
smiData.Solid(13).color = [0.0 0.0 0.0];
smiData.Solid(13).opacity = 0.0;
smiData.Solid(13).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 1.7339942480070705;  % kg
smiData.Solid(1).CoM = [0.00012580878669622573 355.67403499772962 8.1096547605321288e-06];  % mm
smiData.Solid(1).MoI = [14258.337028292923 193.85709748596307 14261.326825814191];  % kg*mm^2
smiData.Solid(1).PoI = [-0.0017870468154190054 0.00045022362423102568 -0.027053668017927628];  % kg*mm^2
smiData.Solid(1).color = [0.6470588235294118 0.61960784313725492 0.58823529411764708];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'base_piston_ikh_analysis*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.26662201264410601;  % kg
smiData.Solid(2).CoM = [4.9999999999999973 25.91256366723259 -66.774193548387146];  % mm
smiData.Solid(2).MoI = [1459.4319481432346 1424.7363152145481 39.13933313942173];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'linkl_2*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0050265482457436681;  % kg
smiData.Solid(3).CoM = [49.999999999999993 0 0];  % mm
smiData.Solid(3).MoI = [0.040212385965949358 4.2088963977693634 4.2088963977693634];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'pin2*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.020106192982974676;  % kg
smiData.Solid(4).CoM = [49.999999999999979 0 0];  % mm
smiData.Solid(4).MoI = [0.64339817545518974 17.07685990687315 17.07685990687315];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'pin3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 3.9980096545419657;  % kg
smiData.Solid(5).CoM = [0.00044557468939642483 0 139.0231706176009];  % mm
smiData.Solid(5).MoI = [35720.415267476579 35740.054565495331 2471.0357738292869];  % kg*mm^2
smiData.Solid(5).PoI = [0 0.26609408210687024 0];  % kg*mm^2
smiData.Solid(5).color = [0.50196078431372548 0.50196078431372548 0.50196078431372548];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'cylinder_base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.66655503161026475;  % kg
smiData.Solid(6).CoM = [143.29848115492794 -6.2801932367149726 5];  % mm
smiData.Solid(6).MoI = [94.816573219377133 21274.434160755471 21358.141483448013];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Link_1_cylinder_1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 20 %23.362324324835136 %kg
smiData.Solid(7).CoM = [372.60057618710152 -8.3452617257885784 38.999999999999993];  % mm
smiData.Solid(7).MoI = [51348.714965378276 14818165.029192826 14830518.666521801];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 -50195.126814033647];  % kg*mm^2
smiData.Solid(7).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Manipulator_part2_for_simulation*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.30982201264410592;  % kg
smiData.Solid(8).CoM = [-11.69082125603858 -6.2801932367149744 5.0000000000000009];  % mm
smiData.Solid(8).MoI = [45.259333139421727 2206.7307809638969 2246.8264138925838];  % kg*mm^2
smiData.Solid(8).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(8).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Link_1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.14343296235127498;  % kg
smiData.Solid(9).CoM = [-24.094121176656909 23.531724060146914 364.99159178955455];  % mm
smiData.Solid(9).MoI = [6105.0173103477591 6104.9825648611186 4.6071909228886518];  % kg*mm^2
smiData.Solid(9).PoI = [0.00092427233673231788 0.00045001008347643788 -0.00055651495023619553];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'Alamarin_piston_rod_analysis*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.40798743446252905;  % kg
smiData.Solid(10).CoM = [76.720490490400323 17.512257633828725 11.235346177411651];  % mm
smiData.Solid(10).MoI = [323.81967611384454 1635.2967974587559 1778.5636229076783];  % kg*mm^2
smiData.Solid(10).PoI = [0 0 -169.16805668138792];  % kg*mm^2
smiData.Solid(10).color = [0.50196078431372548 0.50196078431372548 0.50196078431372548];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'alamarin_cyl_for_manipulator_for_sim*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 28;  % kg
smiData.Solid(11).CoM = [50.000000000000007 -38.884786138864612 -1480.7785361507081];  % mm
smiData.Solid(11).MoI = [19108082.811741743 19119493.158437707 63816.723758876549];  % kg*mm^2
smiData.Solid(11).PoI = [41029.076769300911 0 0];  % kg*mm^2
smiData.Solid(11).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Manipulator_part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.046376190752292504;  % kg
smiData.Solid(12).CoM = [61.000000000000007 0 0];  % mm
smiData.Solid(12).MoI = [2.8057595405136961 58.92481503335032 58.92481503335032];  % kg*mm^2
smiData.Solid(12).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'PIN_simu_1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 1.9462194597851983;  % kg
smiData.Solid(13).CoM = [49.99999999999995 54.581030175232911 -16.410992433641198];  % mm
smiData.Solid(13).MoI = [11673.89381662455 8443.9502854020593 13839.021204751818];  % kg*mm^2
smiData.Solid(13).PoI = [1129.386326636594 0 0];  % kg*mm^2
smiData.Solid(13).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = 'base____1*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(12).Rz.Pos = 0.0;
smiData.CylindricalJoint(12).Pz.Pos = 0.0;
smiData.CylindricalJoint(12).ID = '';

smiData.CylindricalJoint(1).Rz.Pos = -89.999999999999929;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[Alamarin_piston_rod_analysis-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(2).Rz.Pos = 1.4067621674810984;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[pin2-1:-:Alamarin_piston_rod_analysis-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = 1.4067621674810984;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[pin2-2:-:Alamarin_piston_rod_analysis-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(4).Rz.Pos = -113.30571488082461;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[Link_1-2:-:PIN_simu_1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(5).Rz.Pos = 88.816713675675857;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(5).ID = '[Link_1_cylinder_1-1:-:PIN_simu_1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(6).Rz.Pos = 88.816713675675828;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(6).ID = '[Link_1_cylinder_1-2:-:PIN_simu_1-1]';

smiData.CylindricalJoint(7).Rz.Pos = 0.22347584315694205;  % deg
smiData.CylindricalJoint(7).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(7).ID = '[Link_1_cylinder_1-1:-:alamarin_cyl_for_manipulator_for_sim-1]';

smiData.CylindricalJoint(8).Rz.Pos = 0.223475843156935;  % deg
smiData.CylindricalJoint(8).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(8).ID = '[Link_1_cylinder_1-2:-:alamarin_cyl_for_manipulator_for_sim-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(9).Rz.Pos = -105.66951483896007;  % deg
smiData.CylindricalJoint(9).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(9).ID = '[linkl_2-1:-:Manipulator_part2_for_simulation-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(10).Rz.Pos = 74.33048516103996;  % deg
smiData.CylindricalJoint(10).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(10).ID = '[linkl_2-2:-:Manipulator_part2_for_simulation-1]';

smiData.CylindricalJoint(11).Rz.Pos = 90.000000000000028;  % deg
smiData.CylindricalJoint(11).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(11).ID = '[cylinder_base-1:-:base_piston_ikh_analysis-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(12).Rz.Pos = 33.710175067818817;  % deg
smiData.CylindricalJoint(12).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(12).ID = '[pin3-1:-:base_piston_ikh_analysis-1]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(2).Rz.Pos = 0.0;
smiData.PlanarJoint(2).Px.Pos = 0.0;
smiData.PlanarJoint(2).Py.Pos = 0.0;
smiData.PlanarJoint(2).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = -75.525519869962594;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[linkl_2-1:-:Link_1_cylinder_1-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(2).Rz.Pos = -104.47448013003739;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % mm
smiData.PlanarJoint(2).Py.Pos = 0;  % mm
smiData.PlanarJoint(2).ID = '[Link_1_cylinder_1-1:-:linkl_2-2]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(11).Rz.Pos = 0.0;
smiData.RevoluteJoint(11).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = -67.686425669724798;  % deg
smiData.RevoluteJoint(1).ID = '[Manipulator_part1-1:-:Link_1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -66.694285119174666;  % deg
smiData.RevoluteJoint(2).ID = '[Link_1-1:-:PIN_simu_1-1]';

smiData.RevoluteJoint(3).Rz.Pos = -53.40309131346141;  % deg
smiData.RevoluteJoint(3).ID = '[Link_1-1:-:linkl_2-1]';

smiData.RevoluteJoint(4).Rz.Pos = -112.31357433027452;  % deg
smiData.RevoluteJoint(4).ID = '[Manipulator_part1-1:-:Link_1-2]';

smiData.RevoluteJoint(5).Rz.Pos = 53.403091313462149;  % deg
smiData.RevoluteJoint(5).ID = '[Link_1-2:-:linkl_2-2]';

smiData.RevoluteJoint(6).Rz.Pos = 0.99214055055011396;  % deg
smiData.RevoluteJoint(6).ID = '[base____1-1:-:Manipulator_part1-1]';

smiData.RevoluteJoint(7).Rz.Pos = 113.7; % 91.386180482696687;  % deg
smiData.RevoluteJoint(7).ID = '[Manipulator_part1-1:-:Manipulator_part2_for_simulation-1]';

smiData.RevoluteJoint(8).Rz.Pos = -0.99214055055012673;  % deg
smiData.RevoluteJoint(8).ID = '[Manipulator_part1-1:-:pin2-1]';

smiData.RevoluteJoint(9).Rz.Pos = -0.99214055055012673;  % deg
smiData.RevoluteJoint(9).ID = '[Manipulator_part1-1:-:pin2-2]';

smiData.RevoluteJoint(10).Rz.Pos = -0.99214055055012673;  % deg
smiData.RevoluteJoint(10).ID = '[Manipulator_part1-1:-:pin3-1]';

smiData.RevoluteJoint(11).Rz.Pos = 56.289824932181183;  % deg
smiData.RevoluteJoint(11).ID = '[base____1-1:-:cylinder_base-1]';


%Rack and pinion 
% pinion parameters
Pinion.j = [-0.1 0.05 0.02];
Pinion.radius = 0.05;
Pinion.thickness = 0.035;
Pinion.mass = 2;
Pinion.rgb = [0.8, 0.4, 0];

% rack parameters
Rack.length = 0.4;
Rack.height = 0.02;
Rack.thickness = 0.02;
Rack.mass = 3;
Rack.rgb = [0.2, 0.4, 0.7];
%Cyl3.xmax = 0.4; 
%Cyl3.xmin = 0.0; 
