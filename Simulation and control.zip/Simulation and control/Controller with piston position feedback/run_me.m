%%%%%%%%%%%%%Thesis Work%%%%%%%%%%%%5
% Run this file %

clear all
clc

run hydraulic_parameters.m
run boom_simscape_DataFile.m
sim Stroke_Feedback_system.slx