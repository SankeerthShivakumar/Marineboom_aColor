
figure(1)
%Step responses 
subplot(3,1,1)
plot(tout,liftcyl,'r-')
hold on
grid on
plot(tout,ip1,'b--')
axis([0 10 0 0.27])
title('First arm cylinder step response')
legend('Step response','Reference')
ylabel('stroke[m]')
xlabel('Time [s]')
hold off

subplot(3,1,2)
plot(tout,armcyl,'r-')
hold on
grid on
plot(tout,ip2,'b--')
axis([0 10 0 0.5])
title('Second arm cylinder step response')
legend('Step response','Reference')
ylabel('stroke[m]')
xlabel('Time [s]')
hold off

subplot(3,1,3)
plot(tout,rnp,'r-')
hold on
grid on
plot(tout,ip3,'b--')
axis([0 10 0 0.15])
title('Rack and Pinion cylinder step response')
legend('Step response','Reference')
ylabel('stroke[m]')
xlabel('Time [s]')
hold off

% figure(2)
% 
% subplot(4,1,1)
% plot(tout,force)
% hold on
% grid on
% % axis([0 10 0 0.27])
% title('Force')
% legend('Cylinder 1','Cylinder 2','Rack and Pinion Cylinder')
% ylabel('Newton[N]')
% xlabel('Time [s]')
% hold off
% 
% subplot(4,1,2)
% plot(tout,Jointangles)
% hold on
% grid on
% % axis([0 10 0 0.27])
% title('Joint Values(Boom Angle)')
% legend('Cylinder 1','Cylinder 2','Rack and Pinion Cylinder')
% ylabel('Radians[rad]')
% xlabel('Time [s]')
% hold off
% 
% subplot(4,1,3)
% plot(tout,stroke)
% hold on
% grid on
% % axis([0 10 0 0.27])
% title('Cylinder Stroke')
% legend('Cylinder 1','Cylinder 2','Rack and Pinion Cylinder')
% ylabel('Meter[m]')
% xlabel('Time [s]')
% hold off
% 
% subplot(4,1,4)
% plot(tout,velocity)
% hold on
% grid on
% % axis([0 10 0 0.27])
% title('Cylinder Velocity')
% legend('Cylinder 1','Cylinder 2','Rack and Pinion Cylinder')
% ylabel('meter/second[m/s]')
% xlabel('Time [s]')
% hold off
 

% W=10;
%  H=10; 
% set(gcf,'PaperUnits', 'inches','PaperSize',[W,H]);
% set(gcf,'PaperPosition',[0, 0, W, H]);
% print('strokefeedback','-dpng','-r500');