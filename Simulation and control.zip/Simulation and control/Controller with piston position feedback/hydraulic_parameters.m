Cyl.b = 2000; 
Cyl.b2 = 2000; 
Cyl.b3 = 2000; 
%4/3 valve


%2nd order transfer function
Valve.secondorder_delay =  0.03;
Valve_omega =  40.5;
Valve_eta =  0.989;

%Look-up Tabel PA
Valve3.lookupopenPA = [5.33e-4 5.33e-4 6.33e-4 4.93e-2 5.23e-1 5.93e-1 7.43e-1 1];
Valve3.lookupspoolPA = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel PB
Valve3.lookupopenPB = [1 6.13e-1 4.03e-1 3.23e-1 2.93e-1 4.33e-2 4.33e-2 4.33e-2];
Valve3.lookupspoolPB = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%Look-up Tabel BT
Valve3.lookupopenBT = [0 0.00115 0.00115 0.0347 0.1102 0.2088 0.6821 1];
Valve3.lookupspoolBT = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel AT
Valve3.lookupopenAT = [1 0.5189 0.1990 0.1118 0.0343 0.00115 0.00115 0];
Valve3.lookupspoolAT = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Look-up Tabel PA
Valve.lookupopenPA = [5.33e-4 5.33e-4 5.33e-4 4.93e-2 5.23e-1 5.93e-1 7.43e-1 1];
Valve.lookupspoolPA = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel PB
Valve.lookupopenPB = [1 7.13e-1 6.03e-2 5.23e-3 3.93e-4 3.33e-5 3.33e-5 3.33e-5];
Valve.lookupspoolPB = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%Look-up Tabel BT
Valve.lookupopenBT = [0 0.00115 0.00115 0.0347 0.1102 0.2088 0.6821 1];
Valve.lookupspoolBT = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel AT
Valve.lookupopenAT = [1 0.5189 0.1990 0.1118 0.0343 0.00115 0.00115 0];
Valve.lookupspoolAT = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];


%Orifice/Flowpath Parameters

Valve1.QN.PA = 8.33e-5;             % Nominal flow rate [m3/s]
Valve1.QN.BT = 8.33e-5;
Valve1.QN.PB = 8.33e-5;
Valve1.QN.AT = 8.33e-5;
Valve1.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve1.ptr = 0.1e6;                  % Transition pressure [Pa]

Valve2.QN.PA = 4.33e-5;             % Nominal flow rate [m3/s]
Valve2.QN.BT = 4.33e-5;
Valve2.QN.PB = 4.33e-5;
Valve2.QN.AT = 4.33e-5;
Valve2.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve2.ptr = 0.1e6;                  % Transition pressure [Pa]

Valve3.QN.PA = 8.33e-5;             % Nominal flow rate [m3/s]
Valve3.QN.BT = 8.33e-5;
Valve3.QN.PB = 8.33e-5;
Valve3.QN.AT = 8.33e-5;
Valve3.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve3.ptr = 0.1e6;                  % Transition pressure [Pa]

%Supply Pressure
pr_Ps = 200e5;               % Pressure [Pa]
    

% Actuator

%Cylinder Parameters
Cyl.V0A = 0.2e-3;                           % Dead volume at A-side [m3]
Cyl.V0B = 0.2e-3;                           % Dead volume at B-side [m3]
Cyl.B = 1323e6;                             % Effective bulk modulus [Pa]
%Cyl.pa_init = 4450249.10234683;             % [Pa]
%Cyl.pb_init = 5202222.162710 62;             % [Pa]
Cyl1.pa_init = 1e6;
Cyl1.pb_init = 1e6;
Cyl2.pa_init = 1e6;
Cyl2.pb_init = 1e6;
Cyl3.pa_init = 1e6;
Cyl3.pb_init = 1e6;


%Cylinder1
Cyl1.D = 40e-3;                             % Piston diameter A-side [m]
Cyl1.d = 25e-3;                              % Piston diameter B-side [m]
Cyl1.A_A = pi*(Cyl1.D)^2/4;                   % Piston area A-side [m2]
Cyl1.A_B = pi*((Cyl1.D)^2-(Cyl1.d)^2)/4;       % Piston area B-side area [m2]
Cyl1.xmax = 0.2;                           % Stroke Length [m]
v1=0.001;
Cyl1.m = 23.3+23.4+1.4+0.5+0.650+120;
k_end1=(pr_Ps*Cyl1.A_A)/v1;
b_end1=0.5*(k_end1*Cyl1.m)^0.5;
Cyl1.x_min = 0.4;
%Cylinder Control
% Kp.cyl1 = 22.5;
% Ki.cyl1 = 0.001;
% kd.cyl1 = 0.9;
% Fil.cyl1 = 10;
Kp.cyl1 = 14;
Ki.cyl1 = 0.005;
kd.cyl1 = -1.1;
Fil.cyl1 = 1;

%Cylinder2
Cyl2.D = 43e-3;                            % Piston diameter A-side [m]
Cyl2.d = 25e-3;                              % Piston diameter B-side [m]
Cyl2.A_A = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;                   % Piston area A-side [m2]
Cyl2.A_B = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;       % Piston area B-side area [m2]
Cyl2.xmax = 0.455;                           % Stroke Length [m]
Cyl2.m = 23.4+120;
v2=0.001;                                %delta Xmax maxdisplacement plunger can go over natural movement range
k_end2 = (pr_Ps*Cyl2.A_A)/v2;
b_end2 = 0.5*(k_end2*Cyl2.m)^0.5;
Cyl2.x_min = 0;

%Cylinder Control
% Kp.cyl2 = 50
% Ki.cyl2 = 0.1;
% kd.cyl2 = 0.01;
% Fil.cyl2 = 100;
Kp.cyl2 = 40
Ki.cyl2 = 0.1;
kd.cyl2 = 0.01;
Fil.cyl2 = 100;


%Cylinder3
Cyl3.D = 43e-3;                            % Piston diameter A-side [m]
Cyl3.d = 25e-3;                              % Piston diameter B-side [m]
Cyl3.A_A = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;                   % Piston area A-side [m2]
Cyl3.A_B = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;       % Piston area B-side area [m2]
Cyl3.xmax = 0.115;                           % Stroke Length [m]
Cyl3.m = 23.3+23.4+1.4+0.5+0.650+120+10;
%v3=0.002e-3;
% k_end2 = (pr_Ps*Cyl2.A_A)/v2;
% b_end2 = 0.5*(k_end2*Cyl2.m)^0.5;
Cyl3.x_min = 0.055;
%Friction Model
% Cyl2_K = 2000;
% Cyl2_Fs = 1634;                            % Static friction force [N]
% Cyl2_Fc = 1499;                            % Coulombic friction force [N]
% Cyl2_b = 2000;                              % Viscous friction coefficient [Ns/m]
% Cyl2_vs = 0.5;                              % Parameter related to minimum friction vel. [m/s]


fr = 1;

stroke.cyl2 = [0.1096 0.1100 0.1210 0.1252 0.1303 0.1370 0.1419 0.1490 0.1551 0.1602 0.1652 0.1700 0.1755 0.1808 0.1856 0.1906 0.1955 0.2007 0.2115 0.2305 0.2500 0.2762 0.3001 0.3321 0.3612 0.3910 0.4001 0.4100 0.4201 0.4301 0.4401 0.4480]
angle.cyl2 = [4.225e-4 0.0200 0.2881 0.3810 0.4580 0.5043 0.5562 0.6249 0.6794 0.7233 0.7641 0.8015 0.8433 0.8824 0.9171 0.9522 0.9861 1.0216 1.0933 1.2163 1.3402 1.5064 1.6610 1.8780 2.0903 2.3290 2.4009 2.4976 2.5930 2.6979 2.7959 2.8823]
stroke.cyl1 = [0.0600 0.0611 0.0702 0.0803 0.0900 0.1002 0.1103 0.1207 0.1301 0.1400 0.1504 0.1600 0.1700 0.1800 0.1900 0.2002];
angle.cyl1 = [-0.0209 -0.0151 0.0380 .0980 0.1575 0.2211 0.2865 0.3570 0.4224 0.4959 0.5767 0.6566 0.7459 0.8459 0.9593 1.0974];
degree_to_radian = pi/180;

