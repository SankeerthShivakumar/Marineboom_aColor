%_________________Hydraulic system parameters_____________________

%4/3 valve
%2nd order transfer function
Valve.secondorder_delay =  0.03;
Valve_omega =  40.5;
Valve_eta =  0.989;

%Look-up Tabel PA
Valve3.lookupopenPA = [5.33e-4 5.33e-4 6.33e-4 4.93e-2 5.23e-1 5.93e-1 7.43e-1 1];
Valve3.lookupspoolPA = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel PB
Valve3.lookupopenPB = [1 6.13e-1 4.03e-1 3.23e-1 2.93e-1 4.33e-2 4.33e-2 4.33e-2];
Valve3.lookupspoolPB = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%Look-up Tabel BT
Valve3.lookupopenBT = [0 0.00115 0.00115 0.0347 0.1102 0.2088 0.6821 1];
Valve3.lookupspoolBT = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel AT
Valve3.lookupopenAT = [1 0.5189 0.1990 0.1118 0.0343 0.00115 0.00115 0];
Valve3.lookupspoolAT = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Look-up Tabel PA
Valve.lookupopenPA = [5.33e-4 5.33e-4 5.33e-4 4.93e-2 5.23e-1 5.93e-1 7.43e-1 1];
Valve.lookupspoolPA = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel PB
Valve.lookupopenPB = [1 7.13e-1 6.03e-2 5.23e-3 3.93e-4 3.33e-5 3.33e-5 3.33e-5];
Valve.lookupspoolPB = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];

%Look-up Tabel BT
Valve.lookupopenBT = [0 0.00115 0.00115 0.0347 0.1102 0.2088 0.6821 1];
Valve.lookupspoolBT = [-1 -0.5 0 0.2 0.4 0.5 0.8 1];

%Look-up Tabel AT
Valve.lookupopenAT = [1 0.5189 0.1990 0.1118 0.0343 0.00115 0.00115 0];
Valve.lookupspoolAT = [-1 -0.7 -0.5 -0.4 -0.2 0 0.5 1];


%Orifice/Flowpath Parameters

Valve1.QN.PA = 2e-5;                 % Nominal flow rate [m3/s]
Valve1.QN.BT = 2e-5;
Valve1.QN.PB = 2e-5;
Valve1.QN.AT = 2e-5;
Valve1.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve1.ptr = 0.1e6;                  % Transition pressure [Pa]

Valve2.QN.PA = 4.33e-5;              % Nominal flow rate [m3/s]
Valve2.QN.BT = 4.33e-5;
Valve2.QN.PB = 4.33e-5;
Valve2.QN.AT = 4.33e-5;
Valve2.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve2.ptr = 0.1e6;                  % Transition pressure [Pa]

Valve3.QN.PA = 8.33e-5;              % Nominal flow rate [m3/s]
Valve3.QN.BT = 8.33e-5;
Valve3.QN.PB = 8.33e-5;
Valve3.QN.AT = 8.33e-5;
Valve3.dpN = 0.5e6;                  % Nominal pressure difference [Pa]
Valve3.ptr = 0.1e6;                  % Transition pressure [Pa]

%Supply Pressure
pr_Ps = 200e5;                       % Pressure [Pa]
    

% Actuator

%Cylinder Parameters
Cyl.V0A = 0.2e-3;                           % Dead volume at A-side [m3]
Cyl.V0B = 0.2e-3;                           % Dead volume at B-side [m3]
Cyl.B = 1323e6;                             % Effective bulk modulus [Pa]

Cyl1.pa_init = 1e6;                         %Cylinder initial pressure [Pa]
Cyl1.pb_init = 1e6;
Cyl2.pa_init = 1e6;
Cyl2.pb_init = 1e6;
Cyl3.pa_init = 1e6;
Cyl3.pb_init = 1e6;


%Cylinder1
Cyl1.D = 40e-3;                             % Piston diameter A-side [m]
Cyl1.d = 25e-3;                             % Piston diameter B-side [m]
Cyl1.A_A = pi*(Cyl1.D)^2/4;                 % Piston area A-side [m2]
Cyl1.A_B = pi*((Cyl1.D)^2-(Cyl1.d)^2)/4;    % Piston area B-side area [m2]
Cyl1.xmax = 0.2;                            % Stroke Length [m]
v1=0.001;                                   
Cyl1.m = 23.3+23.4+1.4+0.5+0.650+100;       % Mass [Kg]
Cyl1.x_min = 0.4;

%Cylinder 1 Control (gains)
Kp.cyl1 = 0.9;
Ki.cyl1 = 0.0095;
kd.cyl1 = 0.01;
Fil.cyl1 = 100;

%Cylinder2
Cyl2.D = 43e-3;                            % Piston diameter A-side [m]
Cyl2.d = 25e-3;                            % Piston diameter B-side [m]
Cyl2.A_A = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;   % Piston area A-side [m2]
Cyl2.A_B = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;   % Piston area B-side area [m2]
Cyl2.xmax = 0.455;                         % Maximum Stroke Length [m]
Cyl2.m = 23.4+30;                          % Mass [Kg]
v2=0.001;                                  %delta Xmax maxdisplacement plunger can go over natural movement range
Cyl2.x_min = 0;

%Cylinder 2 Control (gains)
Kp.cyl2 = 3;
Ki.cyl2 = 0.0000000001;
kd.cyl2 = -0.000001;
Fil.cyl2 = 100;


%Cylinder3
Cyl3.D = 43e-3;                                % Piston diameter A-side [m]
Cyl3.d = 25e-3;                                % Piston diameter B-side [m]
Cyl3.A_A = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;       % Piston area A-side [m2]
Cyl3.A_B = pi*((Cyl2.D)^2-(Cyl2.d)^2)/4;       % Piston area B-side area [m2]
Cyl3.xmax = 0.115;                             % Maximum Stroke Length [m]
Cyl3.m = 23.3+23.4+1.4+0.5+0.650+120+10;       % Mass acting on cylinder[Kg] 
Cyl3.x_min = 0.055;                            % Minimum Stroke Length [m]
                            
%Friction Model
Cyl.b = 2000;                                % Viscous friction coefficient 
Cyl.b2 = 2000; 
Cyl.b3 = 2000; 

