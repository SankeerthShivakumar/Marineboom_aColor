%%%%%%%%%%%%%Thesis Work%%%%%%%%%%%%5
% Run this file %

clear all
clc

run boomanglefb.m
run boom_simscape_DataFile.m
sim Boom_angle_feedback_.slx